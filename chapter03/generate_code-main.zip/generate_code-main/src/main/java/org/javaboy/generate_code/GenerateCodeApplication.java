package org.javaboy.generate_code;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GenerateCodeApplication {

    public static void main(String[] args) {
        SpringApplication.run(GenerateCodeApplication.class, args);
    }

}
