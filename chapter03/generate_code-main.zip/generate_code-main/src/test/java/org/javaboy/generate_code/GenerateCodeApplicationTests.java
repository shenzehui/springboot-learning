package org.javaboy.generate_code;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GenerateCodeApplicationTests {

    @Test
    void contextLoads() {
    }

}
